<?php
declare(strict_types=1);
date_default_timezone_set('UTC');

function fetchJson($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ["User-Agent: Mozilla/5.0","Accept: application/json"]);
    $res = curl_exec($ch);
    curl_close($ch);
    $json = json_decode($res, true);
    return is_array($json) ? $json : null;
}

// Kumpulan URL API (Indoor dan Voli Pantai)
$api_urls = [
    // API Voli Indoor
    "https://tv.volleyballworld.com/api/client-feed?feed-url=https://zapp-5434-volleyball-tv.web.app/jw/playlists/eMqXVhhW&language=en&_data=routes/api.client-feed",
    
    // API Voli Pantai (Beach Pro Tour)
    "https://tv.volleyballworld.com/api/client-feed?feed-url=https://zapp-5434-volleyball-tv.web.app/jw/playlists/MeMYn3wh&language=en&_data=routes/api.client-feed"
];

$all_entries = [];

// Looping untuk menggabungkan data dari semua playlist
foreach ($api_urls as $url) {
    $data = fetchJson($url);
    if (isset($data['entry']) && is_array($data['entry'])) {
        $all_entries = array_merge($all_entries, $data['entry']);
    }
}

header("Content-Type: audio/x-mpegurl");
echo "#EXTM3U\n\n";

$now = new DateTime("now", new DateTimeZone("UTC"));
$live_events = [];
$upcoming_events = [];
$fallback_url = "https://adptv17.github.io/nissa_channel/upcoming.m3u8";

if (empty($all_entries)) {
    die("Tidak ada data entry dari API VBTV");
}

foreach ($all_entries as $entry) {
    $mediaId = $entry['id'] ?? null;

    // Ambil judul default jika regex gagal
    $defaultTitle = $entry['title'] ?? 'VBTV Event';
    
    $description = $entry['extensions']['description'] ?? '';
    $matchTitle = $defaultTitle; 

    // Parsing judul yang lebih rapi
    if ($description) {
        if (preg_match('/Watch\s+(.*?)\s*-\s*(.*?)\s*\|/', $description, $matches)) {
            $matchTitle = trim($matches[1]) . " vs " . trim($matches[2]);
        }
    }

    // Ambil poster terbesar
    $poster = "https://via.placeholder.com/320x180?text=VBTV";
    if (isset($entry['media_group'][0]['media_item']) && is_array($entry['media_group'][0]['media_item'])) {
        $sizes = [1920,1280,720,640,480,320];
        foreach ($sizes as $s) {
            foreach ($entry['media_group'][0]['media_item'] as $item) {
                if (($item['key'] ?? '') == (string)$s) {
                    $poster = $item['src'] ?? $poster;
                    break 2;
                }
            }
        }
    }

    $siteId = "fM9jRrkn"; // Site ID JWPlayer VBTV
    $isLive = false;

    // Cek waktu pertandingan (scheduled_start)
    $start = isset($entry['extensions']['scheduled_start']) ? new DateTime($entry['extensions']['scheduled_start'], new DateTimeZone("UTC")) : null;

    // Masuk kategori LIVE jika waktunya sudah lewat atau sama dengan sekarang
    if ($start && $now >= $start) {
        $isLive = true;
    }

    // Default URL adalah upcoming/fallback
    $url = $fallback_url;

    // Jika statusnya LIVE, ubah ke URL streaming JWPlayer
    if ($isLive && $mediaId) {
        $url = "https://livecdn.euw1-0005.jwplive.com//live/sites/{$siteId}/media/{$mediaId}/live.isml/.m3u8";
    }

    if ($mediaId) {
        $entryData = [
            'title' => $matchTitle,
            'poster' => $poster,
            'url' => $url
        ];

        // Pakai md5 mediaId sebagai key array untuk mencegah jadwal dobel
        $eventKey = md5($mediaId); 
        
        if ($isLive) {
            $live_events[$eventKey] = $entryData;
        } else {
            $upcoming_events[$eventKey] = $entryData;
        }
    }
}

// Fungsi cetak format M3U
function generateM3U($events, $groupTitle) {
    foreach ($events as $e) {
        echo "#EXTINF:-1 tvg-logo=\"{$e['poster']}\" group-title=\"{$groupTitle}\",{$e['title']}\n";
        echo $e['url'] . "\n\n";
    }
}

// Tampilkan kategori LIVE di urutan teratas
generateM3U($live_events, "_LIVE | EVENT");

// Tampilkan kategori UPCOMING di bawahnya
generateM3U($upcoming_events, "_UPCOMING");
?>